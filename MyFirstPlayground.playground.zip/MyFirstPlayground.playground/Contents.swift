import UIKit

var str = "Hello, playground" //Variable
print(str)
//Comentario
/*C
o
m
e
n
t
a
r
i
o*/
3 + 4
var 😎 = "FELIZ"
var status = "😄"
print(status)
print (😎)
let favoriteBook = "The Sun Also Rises" //Constantes
str = "Hello, Geovanni"
print(str)
var str1:String = "Fonte <3"

