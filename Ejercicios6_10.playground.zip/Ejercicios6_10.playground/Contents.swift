import UIKit
//Ejercicio 6

func rowTheBoat() {
    print("Bailando, bailando")
    print("Con tu quimica y tambien tu anatomìa, la cerveza y el tequila")
}

func merrilyDream() {
    print("Rápido, rápido, rápido, rápido")
    print("Rema en el barquito")
}

func breatheBetweenVerses() {
    print("        ~        ")
}

func crocodileScream(){
    print ("BadBunny baby")
}
func laughingSubmarine() {
    print("¡Ja, ja! Los engañé")
    print("Soy un submarino")
}
func laughingAlternative(){
    laughingSubmarine()
    print("Submarino amarillo jaja")
}
func verseOne() {
    rowTheBoat()
    merrilyDream()
}

breatheBetweenVerses()
rowTheBoat()
verseOne()
verseOne()
rowTheBoat()
merrilyDream()
crocodileScream()
laughingAlternative()

func Crema(){
    print("Ahora te traigo la crema")
    print("De la HH que rompe fronteras")
}
func Normas(){
    print("Asi es, tengo que seguir cambiando normas y eso lo demuestro")
}
func Chiquillo(){
    print("En esto yo empece desde que yo era un chiquillo")
}

Crema()
Normas()
Crema()
Chiquillo()
Crema()


